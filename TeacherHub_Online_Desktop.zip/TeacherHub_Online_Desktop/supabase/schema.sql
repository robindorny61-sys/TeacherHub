-- TeacherHub database schema for Supabase/PostgreSQL.
-- Run in Supabase SQL Editor. Test with fake data before real school use.
create extension if not exists pgcrypto;

create type public.app_role as enum ('teacher','student');
create type public.attendance_status as enum ('present','absent','late','excused');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  display_name text,
  role public.app_role not null default 'student',
  created_at timestamptz not null default now()
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  subject text check (subject is null or char_length(subject) <= 100),
  school_year text check (school_year is null or char_length(school_year) <= 20),
  owner_id uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table public.class_members (
  class_id uuid not null references public.classes(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (class_id, student_id)
);

create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 160),
  description text check (description is null or char_length(description) <= 10000),
  due_at timestamptz,
  created_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table public.grades (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  score numeric(7,2) not null check (score >= 0),
  max_score numeric(7,2) not null check (max_score > 0 and score <= max_score),
  comment text check (comment is null or char_length(comment) <= 1000),
  graded_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  date date not null,
  status public.attendance_status not null,
  note text check (note is null or char_length(note) <= 300),
  recorded_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique (class_id, student_id, date)
);

create index classes_owner_idx on public.classes(owner_id);
create index assignments_class_idx on public.assignments(class_id);
create index grades_student_idx on public.grades(student_id);
create index attendance_class_date_idx on public.attendance(class_id, date);

-- Create a profile for each new auth user. All new accounts start as students.
-- A trusted school administrator must promote teacher accounts manually.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email, display_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)),
    'student'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Role helper. SECURITY DEFINER avoids recursive RLS reads of profiles.
create or replace function public.current_app_role()
returns public.app_role language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = (select auth.uid())
$$;

create or replace function public.owns_class(target_class uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.classes c where c.id = target_class and c.owner_id = (select auth.uid()))
$$;

create or replace function public.is_class_member(target_class uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.class_members cm where cm.class_id = target_class and cm.student_id = (select auth.uid()))
$$;

alter table public.profiles enable row level security;
alter table public.classes enable row level security;
alter table public.class_members enable row level security;
alter table public.assignments enable row level security;
alter table public.grades enable row level security;
alter table public.attendance enable row level security;

-- Profiles: user can read/update own non-role fields. Teachers can read students in their classes.
create policy "profiles read self" on public.profiles for select to authenticated
  using (id = (select auth.uid()));
create policy "profiles update self display fields" on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()) and role = public.current_app_role());
create policy "teachers read their class students" on public.profiles for select to authenticated
  using (public.current_app_role() = 'teacher' and exists (
    select 1 from public.class_members cm join public.classes c on c.id=cm.class_id
    where cm.student_id=profiles.id and c.owner_id=(select auth.uid())
  ));

-- Classes: teachers own their classes; students see only classes they joined.
create policy "class owners manage classes" on public.classes for all to authenticated
  using (owner_id=(select auth.uid()) and public.current_app_role()='teacher')
  with check (owner_id=(select auth.uid()) and public.current_app_role()='teacher');
create policy "students read joined classes" on public.classes for select to authenticated
  using (public.is_class_member(id));

-- Class membership: teacher manages membership for own classes; student reads own memberships.
create policy "class owners manage membership" on public.class_members for all to authenticated
  using (public.owns_class(class_id) and public.current_app_role()='teacher')
  with check (public.owns_class(class_id) and public.current_app_role()='teacher');
create policy "students read own membership" on public.class_members for select to authenticated
  using (student_id=(select auth.uid()));

-- Assignments visible to class owner or members; only class owner can manage.
create policy "read assignments in accessible classes" on public.assignments for select to authenticated
  using (public.owns_class(class_id) or public.is_class_member(class_id));
create policy "class owners manage assignments" on public.assignments for all to authenticated
  using (public.owns_class(class_id) and public.current_app_role()='teacher')
  with check (public.owns_class(class_id) and public.current_app_role()='teacher' and created_by=(select auth.uid()));

-- Grades: teacher owner of assignment's class can manage; student can read only own.
create policy "teachers read grades for their classes" on public.grades for select to authenticated
  using (exists(select 1 from public.assignments a join public.classes c on c.id=a.class_id where a.id=assignment_id and c.owner_id=(select auth.uid()) and public.current_app_role()='teacher'));
create policy "students read own grades" on public.grades for select to authenticated
  using (student_id=(select auth.uid()) and public.is_class_member((select class_id from public.assignments where id=assignment_id)));
create policy "teachers manage grades for their classes" on public.grades for all to authenticated
  using (exists(select 1 from public.assignments a join public.classes c on c.id=a.class_id where a.id=assignment_id and c.owner_id=(select auth.uid()) and public.current_app_role()='teacher')
    and graded_by=(select auth.uid()))
  with check (exists(select 1 from public.assignments a join public.classes c on c.id=a.class_id where a.id=assignment_id and c.owner_id=(select auth.uid()) and public.current_app_role()='teacher')
    and graded_by=(select auth.uid()));

-- Attendance: teacher owner can manage; student can see own records only.
create policy "teachers read attendance for their classes" on public.attendance for select to authenticated
  using (public.owns_class(class_id) and public.current_app_role()='teacher');
create policy "students read own attendance" on public.attendance for select to authenticated
  using (student_id=(select auth.uid()) and public.is_class_member(class_id));
create policy "teachers manage attendance for their classes" on public.attendance for all to authenticated
  using (public.owns_class(class_id) and public.current_app_role()='teacher' and recorded_by=(select auth.uid()))
  with check (public.owns_class(class_id) and public.current_app_role()='teacher' and recorded_by=(select auth.uid()));

-- IMPORTANT: This schema is a starter, not a school-certified product.
-- Teacher promotion is intentionally manual and must be done only by a trusted admin:
-- update public.profiles set role='teacher' where email='verified-school-email@example.be';
-- Never let users change their own role through client-side code.
