# Supabase setup

Run `schema.sql` in the Supabase SQL Editor.

The schema deliberately creates all new accounts as `student`. A trusted administrator must promote verified teacher accounts manually. Do not add any self-service role selector.

Before production:
- Test each RLS policy with two separate teacher accounts and two student accounts.
- Confirm students cannot read other students' grades or attendance.
- Confirm teachers can only manage records for classes they own.
- Add a controlled class-enrollment/invitation flow before inviting real students.
- Ask your school's privacy/security lead to review the schema and retention practices.
