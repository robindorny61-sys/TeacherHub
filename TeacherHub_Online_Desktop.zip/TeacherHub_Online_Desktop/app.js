/* TeacherHub starter. Frontend keys are public; database access is protected by Supabase RLS. */
(() => {
  const cfg = window.TEACHERHUB_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const setupNotice = $("setupNotice");
  const authView = $("authView");
  const appView = $("appView");
  let supabase = null;
  let currentUser = null;
  let profile = null;
  let activePage = "dashboard";
  let cachedClasses = [];

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const msg = (id, text, isError=false) => { const el=$(id); if(el){el.textContent=text; el.style.color=isError?"#b42318":"#12805c";} };
  const initials = (email) => (email || "T").trim().charAt(0).toUpperCase();

  if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY || cfg.SUPABASE_URL.includes("JOUW-PROJECT")) {
    setupNotice.classList.remove("hidden");
    setupNotice.textContent = "Eerst instellen: maak config.js op basis van config.js.example en vul je Supabase-projectgegevens in.";
  } else if (window.supabase?.createClient) {
    supabase = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    supabase.auth.getSession().then(({data}) => data.session ? boot(data.session.user) : showAuth());
    supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) boot(session.user);
      else showAuth();
    });
  } else {
    setupNotice.classList.remove("hidden");
    setupNotice.textContent = "Supabase-bibliotheek kon niet geladen worden. Controleer je internetverbinding.";
  }

  function showAuth(){ authView.classList.remove("hidden"); appView.classList.add("hidden"); currentUser=null; }
  async function boot(user) {
    if (!supabase || !user) return;
    currentUser = user;
    authView.classList.add("hidden"); appView.classList.remove("hidden");
    $("userEmail").textContent = user.email || "Gebruiker";
    $("avatar").textContent = $("topAvatar").textContent = initials(user.email);
    await loadProfile();
    await loadClasses();
    renderPage(activePage);
  }
  async function loadProfile(){
    const {data,error}=await supabase.from("profiles").select("id,email,display_name,role").eq("id",currentUser.id).maybeSingle();
    if(error){console.error(error);profile=null;return;}
    profile=data;
    $("userRole").textContent = profile?.role === "teacher" ? "Leerkracht" : profile?.role === "student" ? "Leerling" : "Rol nog niet ingesteld";
  }
  async function loadClasses(){
    const {data,error}=await supabase.from("classes").select("id,name,subject,school_year,owner_id,created_at").order("created_at",{ascending:false});
    if(error){console.error(error);cachedClasses=[];} else cachedClasses=data||[];
  }
  function titleFor(page){return ({dashboard:"Overzicht",classes:"Klassen",assignments:"Opdrachten",grades:"Punten",attendance:"Aanwezigheden",ai:"AI-leshulp",settings:"Instellingen"})[page]||"Overzicht";}
  async function renderPage(page){
    activePage=page; $("pageTitle").textContent=titleFor(page);
    document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
    const c=$("pageContent"); c.innerHTML='<div class="empty">Laden…</div>';
    if(!profile){c.innerHTML=`<div class="panel"><h3>Je profiel is nog niet klaar</h3><p>Vraag de beheerder om je rol in de tabel <code>profiles</code> in te stellen. Dit voorkomt dat leerlingen leerkrachtrechten krijgen.</p></div>`;return;}
    if(page==="dashboard") return renderDashboard(c);
    if(page==="classes") return renderClasses(c);
    if(page==="assignments") return renderAssignments(c);
    if(page==="grades") return renderGrades(c);
    if(page==="attendance") return renderAttendance(c);
    if(page==="ai") return renderAI(c);
    if(page==="settings") return renderSettings(c);
  }
  const isTeacher = () => profile?.role === "teacher";
  function roleWarning(){return isTeacher()?"":"<div class='notice'>Je bent aangemeld als leerling. Je kunt alleen onderdelen zien waarvoor je rechten hebt. Voor klasbeheer en punteninvoer is een leerkrachtaccount nodig.</div>";}
  async function renderDashboard(c){
    const [cls,ass,grades,att] = await Promise.all([
      supabase.from("classes").select("id",{count:"exact",head:true}),
      supabase.from("assignments").select("id",{count:"exact",head:true}),
      supabase.from("grades").select("id",{count:"exact",head:true}),
      supabase.from("attendance").select("id",{count:"exact",head:true})
    ]);
    c.innerHTML=`<section class="welcome"><div><p class="eyebrow" style="color:#d7e5ff">WELKOM BIJ TEACHERHUB</p><h3>Goedemorgen, ${escapeHtml(profile.display_name||currentUser.email.split("@")[0])} 👋</h3><p>Je lessen en klasadministratie overzichtelijk op één plek.</p></div><div class="welcome-icon">✦</div></section>
      <section class="stats"><div class="stat"><span class="stat-icon">▤</span><div class="stat-label">Klassen</div><div class="stat-value">${cls.count??"—"}</div></div><div class="stat"><span class="stat-icon">✓</span><div class="stat-label">Opdrachten</div><div class="stat-value">${ass.count??"—"}</div></div><div class="stat"><span class="stat-icon">▥</span><div class="stat-label">Punten</div><div class="stat-value">${grades.count??"—"}</div></div><div class="stat"><span class="stat-icon">◷</span><div class="stat-label">Aanwezigheden</div><div class="stat-value">${att.count??"—"}</div></div></section>
      <section class="content-grid"><div class="panel"><div class="panel-head"><h3>Start snel</h3><span class="tag">Jouw werkplek</span></div><div class="item-list"><div class="item-card"><div><h4>Klassen beheren</h4><p>Maak een klas aan en voeg lesmateriaal toe.</p></div><button class="secondary small-btn" data-goto="classes">Openen</button></div><div class="item-card"><div><h4>Opdracht maken</h4><p>Deel instructies en een deadline.</p></div><button class="secondary small-btn" data-goto="assignments">Openen</button></div><div class="item-card"><div><h4>AI-leshulp</h4><p>Maak een eerste lesopzet zonder leerlinggegevens.</p></div><button class="secondary small-btn" data-goto="ai">Openen</button></div></div></div><div class="panel"><h3>Privacy en veiligheid</h3><p>Gebruik voor echte leerlingen alleen de gegevens die noodzakelijk zijn en die je school toestaat. Deel nooit wachtwoorden of gevoelige leerlinginformatie in AI-tools.</p><div class="notice">Schermmonitoring is niet ingebouwd. Dit starterproject neemt geen screenshots, activeert geen camera of microfoon en kijkt niet mee op leerlingtoestellen.</div></div></section>`;
  }
  async function renderClasses(c){
    const {data,error}=await supabase.from("classes").select("id,name,subject,school_year,owner_id,created_at").order("created_at",{ascending:false});
    cachedClasses=data||[];
    c.innerHTML=`${roleWarning()}<div class="toolbar"><h3>Jouw klassen</h3>${isTeacher()?'<button class="primary" id="newClassBtn">+ Klas maken</button>':""}</div><div id="classFormHost"></div>${error?`<p class="inline-error">${escapeHtml(error.message)}</p>`:""}<div class="item-list">${cachedClasses.length?cachedClasses.map(x=>`<div class="item-card"><div><h4>${escapeHtml(x.name)}</h4><p>${escapeHtml(x.subject||"Geen vak")} · ${escapeHtml(x.school_year||"Schooljaar niet ingevuld")}</p></div><div class="item-actions"><span class="tag">${x.owner_id===currentUser.id?"Eigen klas":"Gedeeld"}</span></div></div>`).join(""):'<div class="empty">Nog geen klassen. Maak je eerste klas aan.</div>'}</div>`;
    $("newClassBtn")?.addEventListener("click",()=>{$("classFormHost").innerHTML=`<div class="panel" style="margin-bottom:16px"><h3>Nieuwe klas</h3><form id="classForm" class="form-grid"><div><label>Naam klas *</label><input name="name" required maxlength="100" placeholder="bv. 2A Sport"></div><div><label>Vak</label><input name="subject" maxlength="100" placeholder="bv. Bewegingsleer"></div><div><label>Schooljaar</label><input name="school_year" maxlength="20" placeholder="2026-2027"></div><div class="full form-actions"><button class="primary">Opslaan</button><button type="button" class="secondary" id="cancelClass">Annuleren</button></div></form><p id="classMsg" class="message"></p></div>`;
      $("cancelClass").onclick=()=> $("classFormHost").innerHTML="";
      $("classForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const {error}=await supabase.from("classes").insert({name:f.get("name").trim(),subject:f.get("subject").trim()||null,school_year:f.get("school_year").trim()||null,owner_id:currentUser.id});if(error)msg("classMsg",error.message,true);else renderPage("classes");};});
  }
  async function classOptions(){
    const {data}=await supabase.from("classes").select("id,name").order("name");
    return (data||[]).map(x=>`<option value="${escapeHtml(x.id)}">${escapeHtml(x.name)}</option>`).join("");
  }
  async function renderAssignments(c){
    const [{data,error},opts]=await Promise.all([supabase.from("assignments").select("id,title,description,due_at,class_id,created_at,created_by,classes(name)").order("created_at",{ascending:false}),classOptions()]);
    c.innerHTML=`${roleWarning()}<div class="toolbar"><h3>Opdrachten</h3>${isTeacher()?'<button class="primary" id="newAssignmentBtn">+ Opdracht maken</button>':""}</div><div id="assignmentFormHost"></div>${error?`<p class="inline-error">${escapeHtml(error.message)}</p>`:""}<div class="item-list">${(data||[]).length?(data||[]).map(a=>`<div class="item-card"><div><h4>${escapeHtml(a.title)}</h4><p>${escapeHtml(a.classes?.name||"Klas")} · ${escapeHtml(a.due_at?new Date(a.due_at).toLocaleString("nl-BE"):"Geen deadline")}</p><p>${escapeHtml(a.description||"")}</p></div><span class="tag">Opdracht</span></div>`).join(""):'<div class="empty">Nog geen opdrachten.</div>'}</div>`;
    $("newAssignmentBtn")?.addEventListener("click",()=>{$("assignmentFormHost").innerHTML=`<div class="panel" style="margin-bottom:16px"><h3>Nieuwe opdracht</h3><form id="assignmentForm" class="form-grid"><div class="full"><label>Titel *</label><input name="title" required maxlength="160"></div><div class="full"><label>Beschrijving</label><textarea name="description" maxlength="10000"></textarea></div><div><label>Klas *</label><select name="class_id" required>${opts}</select></div><div><label>Deadline</label><input type="datetime-local" name="due_at"></div><div class="full form-actions"><button class="primary">Opslaan</button><button type="button" class="secondary" id="cancelAssignment">Annuleren</button></div></form><p id="assignmentMsg" class="message"></p></div>`;
      $("cancelAssignment").onclick=()=> $("assignmentFormHost").innerHTML="";
      $("assignmentForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const due=f.get("due_at");const {error}=await supabase.from("assignments").insert({title:f.get("title").trim(),description:f.get("description").trim()||null,class_id:f.get("class_id"),due_at:due?new Date(due).toISOString():null,created_by:currentUser.id});if(error)msg("assignmentMsg",error.message,true);else renderPage("assignments");};});
  }
  async function renderGrades(c){
    const [{data,error},students]=await Promise.all([supabase.from("grades").select("id,score,max_score,comment,created_at,student_id,assignment_id,assignments(title)").order("created_at",{ascending:false}),supabase.from("profiles").select("id,display_name,email,role").eq("role","student").order("email")]);
    c.innerHTML=`${roleWarning()}<div class="toolbar"><h3>Puntenboek</h3>${isTeacher()?'<button class="primary" id="newGradeBtn">+ Punt toevoegen</button>':""}</div><div id="gradeFormHost"></div><div class="panel table-wrap">${error?`<p class="inline-error">${escapeHtml(error.message)}</p>`:""}<table><thead><tr><th>Leerling-ID</th><th>Opdracht</th><th>Score</th><th>Opmerking</th><th>Datum</th></tr></thead><tbody>${(data||[]).map(g=>`<tr><td>${escapeHtml((students.data||[]).find(s=>s.id===g.student_id)?.display_name||(students.data||[]).find(s=>s.id===g.student_id)?.email||g.student_id.slice(0,8))}</td><td>${escapeHtml(g.assignments?.title||"—")}</td><td>${escapeHtml(g.score)} / ${escapeHtml(g.max_score)}</td><td>${escapeHtml(g.comment||"—")}</td><td>${new Date(g.created_at).toLocaleDateString("nl-BE")}</td></tr>`).join("")||'<tr><td colspan="5">Nog geen punten.</td></tr>'}</tbody></table></div><p class="footer-note">Leerlingnamen en cijfers zijn persoonsgegevens. Beperk toegang tot de juiste klas en deel geen exports publiek.</p>`;
    $("newGradeBtn")?.addEventListener("click",async()=>{const as=await supabase.from("assignments").select("id,title").order("title");const st=students.data||[];$("gradeFormHost").innerHTML=`<div class="panel" style="margin-bottom:16px"><h3>Punt toevoegen</h3><form id="gradeForm" class="form-grid"><div><label>Leerling *</label><select name="student_id" required>${st.map(s=>`<option value="${s.id}">${escapeHtml(s.display_name||s.email)}</option>`).join("")}</select></div><div><label>Opdracht *</label><select name="assignment_id" required>${(as.data||[]).map(a=>`<option value="${a.id}">${escapeHtml(a.title)}</option>`).join("")}</select></div><div><label>Behaalde punten *</label><input name="score" type="number" min="0" step="0.1" required></div><div><label>Maximum *</label><input name="max_score" type="number" min="0.1" step="0.1" value="10" required></div><div class="full"><label>Opmerking</label><input name="comment" maxlength="1000"></div><div class="full form-actions"><button class="primary">Opslaan</button><button type="button" class="secondary" id="cancelGrade">Annuleren</button></div></form><p id="gradeMsg" class="message"></p></div>`;
      $("cancelGrade").onclick=()=> $("gradeFormHost").innerHTML="";
      $("gradeForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),score=Number(f.get("score")),max=Number(f.get("max_score"));if(score<0||max<=0||score>max){msg("gradeMsg","Controleer de punten: score moet tussen 0 en het maximum liggen.",true);return;}const {error}=await supabase.from("grades").insert({student_id:f.get("student_id"),assignment_id:f.get("assignment_id"),score,max_score:max,comment:f.get("comment").trim()||null,graded_by:currentUser.id});if(error)msg("gradeMsg",error.message,true);else renderPage("grades");};});
  }
  async function renderAttendance(c){
    const [{data,error},opts]=await Promise.all([supabase.from("attendance").select("id,date,status,note,student_id,class_id,profiles(display_name,email),classes(name)").order("date",{ascending:false}).limit(100),classOptions()]);
    c.innerHTML=`${roleWarning()}<div class="toolbar"><h3>Aanwezigheden</h3>${isTeacher()?'<button class="primary" id="newAttendanceBtn">+ Registreren</button>':""}</div><div id="attendanceFormHost"></div>${error?`<p class="inline-error">${escapeHtml(error.message)}</p>`:""}<div class="panel table-wrap"><table><thead><tr><th>Datum</th><th>Leerling</th><th>Klas</th><th>Status</th><th>Notitie</th></tr></thead><tbody>${(data||[]).map(a=>`<tr><td>${escapeHtml(a.date)}</td><td>${escapeHtml(a.profiles?.display_name||a.profiles?.email||a.student_id.slice(0,8))}</td><td>${escapeHtml(a.classes?.name||"—")}</td><td><span class="tag ${a.status==="present"?"success":a.status==="absent"?"danger":""}">${({present:"Aanwezig",absent:"Afwezig",late:"Te laat",excused:"Gewettigd"})[a.status]||escapeHtml(a.status)}</span></td><td>${escapeHtml(a.note||"—")}</td></tr>`).join("")||'<tr><td colspan="5">Nog geen registraties.</td></tr>'}</tbody></table></div>`;
    $("newAttendanceBtn")?.addEventListener("click",async()=>{const st=await supabase.from("profiles").select("id,email,display_name").eq("role","student").order("email");$("attendanceFormHost").innerHTML=`<div class="panel" style="margin-bottom:16px"><h3>Aanwezigheid registreren</h3><form id="attendanceForm" class="form-grid"><div><label>Klas *</label><select name="class_id" required>${opts}</select></div><div><label>Leerling *</label><select name="student_id" required>${(st.data||[]).map(s=>`<option value="${s.id}">${escapeHtml(s.display_name||s.email)}</option>`).join("")}</select></div><div><label>Datum *</label><input name="date" type="date" required value="${new Date().toISOString().slice(0,10)}"></div><div><label>Status *</label><select name="status"><option value="present">Aanwezig</option><option value="absent">Afwezig</option><option value="late">Te laat</option><option value="excused">Gewettigd</option></select></div><div class="full"><label>Notitie (optioneel, houd dit beperkt)</label><input name="note" maxlength="300"></div><div class="full form-actions"><button class="primary">Opslaan</button><button type="button" class="secondary" id="cancelAttendance">Annuleren</button></div></form><p id="attendanceMsg" class="message"></p></div>`;
      $("cancelAttendance").onclick=()=> $("attendanceFormHost").innerHTML="";
      $("attendanceForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const {error}=await supabase.from("attendance").insert({class_id:f.get("class_id"),student_id:f.get("student_id"),date:f.get("date"),status:f.get("status"),note:f.get("note").trim()||null,recorded_by:currentUser.id});if(error)msg("attendanceMsg",error.message,true);else renderPage("attendance");};});
  }
  async function renderAI(c){
    c.innerHTML=`<div class="toolbar"><h3>AI-leshulp</h3><span class="tag">Conceptversie</span></div><div class="content-grid"><div class="panel"><h3>Maak een lesopzet</h3><p>Beschrijf het vak, onderwerp en niveau. Gebruik geen namen, cijfers, medische info of andere persoonsgegevens van leerlingen.</p><form id="aiForm"><div class="field"><label>Vak en onderwerp</label><input name="topic" required maxlength="180" placeholder="bv. Biologie — het skelet"></div><div class="field"><label>Leeftijd / niveau</label><input name="level" required maxlength="100" placeholder="bv. 2e jaar secundair"></div><div class="field"><label>Lesduur</label><select name="duration"><option>30 minuten</option><option selected>50 minuten</option><option>100 minuten</option></select></div><div class="field"><label>Wat moet de les bevatten?</label><textarea name="goals" maxlength="3000" placeholder="Leerdoelen, uitleg, oefeningen..."></textarea></div><button class="primary" type="submit">Maak lesopzet</button></form><p id="aiMessage" class="message"></p></div><div class="panel"><h3>AI-resultaat</h3><div id="aiResult" class="empty">Je lesopzet verschijnt hier.</div><p class="tiny">Deze demo stuurt niets naar een AI-provider. Voor echte AI moet je de optionele beveiligde backendfunctie installeren en een eigen API-sleutel als serversecret instellen. AI-output moet je controleren voor je die aan leerlingen geeft.</p></div></div>`;
    $("aiForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const text=`LESOPZET — ${f.get("topic")}\nNiveau: ${f.get("level")}\nDuur: ${f.get("duration")}\n\n1. Leerdoelen\n- Formuleer 2 à 3 meetbare leerdoelen passend bij het onderwerp.\n\n2. Lesverloop\n- Start (5 min): activeer voorkennis met een korte vraag.\n- Uitleg: leg de kernbegrippen stapsgewijs uit met een voorbeeld.\n- Oefenen: laat leerlingen individueel of per twee oefenen.\n- Afsluiting: controleer de leerdoelen met een exit-ticket.\n\n3. Differentiatie\n- Extra ondersteuning: geef een stappenplan en voorbeeld.\n- Extra uitdaging: laat leerlingen zelf een toepassing bedenken.\n\n4. Controleer begrip\n- Stel 3 korte vragen die rechtstreeks aansluiten bij de leerdoelen.\n\nAandachtspunten van de leerkracht: ${f.get("goals")||"Vul eigen leerdoelen aan."}\n\nDit is een lokale sjabloon, geen gegenereerd AI-antwoord. Voor AI-generatie moet een beveiligde backend worden ingesteld.`;
      $("aiResult").className="";$("aiResult").innerHTML=`<pre style="white-space:pre-wrap;font:inherit;font-size:13px;line-height:1.65">${escapeHtml(text)}</pre><button class="secondary small-btn" id="copyAI">Kopieer lesopzet</button>`;$("copyAI").onclick=()=>navigator.clipboard.writeText(text).then(()=>msg("aiMessage","Lesopzet gekopieerd."),()=>msg("aiMessage","Kopiëren is niet gelukt.",true));msg("aiMessage","Er is een les-sjabloon gemaakt. Dit is nog geen echte AI-generatie.");};
  }
  function renderSettings(c){
    c.innerHTML=`<div class="content-grid"><div class="panel"><h3>Account</h3><p><strong>E-mail:</strong> ${escapeHtml(currentUser.email)}</p><p><strong>Rol:</strong> ${escapeHtml(profile.role||"Niet ingesteld")}</p><p><strong>Naam:</strong> ${escapeHtml(profile.display_name||"Niet ingesteld")}</p><p class="tiny">Je rol wordt door een bevoegde beheerder in de database ingesteld. Je kunt jezelf niet via de website leerkrachtrechten geven.</p></div><div class="panel"><h3>Veilig gebruik</h3><ul style="font-size:13px;line-height:1.8;color:#65738b;padding-left:20px"><li>Gebruik unieke wachtwoorden en schakel e-mailbevestiging in.</li><li>Deel geen Supabase service-role sleutel.</li><li>Publiceer geen exports met leerlinggegevens op GitHub.</li><li>Gebruik testdata tot de school de privacy-afspraken heeft goedgekeurd.</li><li>Monitoring is niet ingebouwd in deze starter.</li></ul></div></div>`;
  }
  $("authForm").addEventListener("submit",async e=>{e.preventDefault();if(!supabase){msg("authMessage","Vul eerst config.js in.",true);return;}const email=$("email").value.trim(),password=$("password").value;const {error}=await supabase.auth.signInWithPassword({email,password});if(error)msg("authMessage",error.message,true);});
  $("signUpBtn").addEventListener("click",async()=>{if(!supabase){msg("authMessage","Vul eerst config.js in.",true);return;}const email=$("email").value.trim(),password=$("password").value;if(!email||password.length<8){msg("authMessage","Vul een e-mailadres en een wachtwoord van minstens 8 tekens in.",true);return;}const {data,error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:location.origin+location.pathname}});if(error)msg("authMessage",error.message,true);else msg("authMessage",data.session?"Account gemaakt.":"Controleer je e-mail om je account te bevestigen.");});
  $("signOutBtn").addEventListener("click",async()=>{if(supabase)await supabase.auth.signOut();showAuth();});
  document.addEventListener("click",e=>{const b=e.target.closest("[data-page],[data-goto]");if(b)renderPage(b.dataset.page||b.dataset.goto);});
})();