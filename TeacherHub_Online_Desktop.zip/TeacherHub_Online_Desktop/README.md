# TeacherHub — online desktopstarter voor leerkrachten

Een online desktopgerichte webapp-starter in modern blauw (bedoeld voor gebruik via een browser op een computer) met:
- aanmelden en accounts via Supabase Auth
- klassen, opdrachten, puntenboek en aanwezigheden
- lokale lesopzet-sjabloon voor AI-lesvoorbereiding
- rolmodel `teacher` / `student`
- databasebeveiliging met Supabase Row Level Security (RLS)

## Belangrijke beperkingen

1. **Dit is een starterproject, geen volledig schoolbeheersysteem.** Test met fictieve gegevens. Laat de school-ICT'er en privacyverantwoordelijke de beveiliging controleren vóór gebruik met echte leerlingen.
2. **Schermmonitoring is niet ingebouwd.** De website maakt geen screenshots en gebruikt geen camera of microfoon. GitHub Pages kan niet op eigen kracht live schermen van andere apparaten bekijken. Gebruik alleen een schoolgoedgekeurde, transparante monitoringoplossing met passende toestemming en apparaatondersteuning.
3. **AI is nog geen echte AI-koppeling.** De AI-leshulp maakt een lokaal sjabloon. Voor echte generatie is een serverfunctie en provider-secret nodig; API-gebruik kan geld kosten. Zet nooit een API-sleutel in `app.js`, `config.js` of GitHub Pages.
4. **Accountrollen zijn niet zelf te kiezen.** Nieuwe accounts krijgen standaard de rol `student`. Een vertrouwde beheerder moet leerkrachtaccounts handmatig promoveren.
5. De meegeleverde policies zijn een bruikbare basis maar moeten vóór productie grondig getest worden. Er is nog geen uitnodigingssysteem, leerlingen koppelen aan een klas via de UI, rapportexport, inzendingen van leerlingen of auditdashboard.

## Desktop-only ontwerp

Deze versie is gericht op een computerscherm en gebruikt een vaste minimale breedte. Op kleine schermen kan horizontaal scrollen nodig zijn. De site is online te openen via een browser; er is geen desktopinstallatie nodig. De database en accounts vereisen wel een internetverbinding.

## Architectuur

- Frontend: HTML, CSS en JavaScript op GitHub Pages.
- Auth/database: Supabase (gratis tier beschikbaar, met limieten en voorwaarden).
- AI (optioneel, later): server-side functie zoals Supabase Edge Function; API-key als secret.
- Schermmonitoring: aparte, goedgekeurde tool/integratie; niet inbegrepen.

## Installatie op Windows

### 1. GitHub-repository maken
1. Ga naar https://github.com en meld je aan.
2. Klik op **New repository**.
3. Noem de repository `TeacherHub`.
4. Kies **Public** alleen als je begrijpt dat broncode dan openbaar is; gebruik nooit echte leerlinggegevens in de repository. Private is veiliger voor broncode, maar GitHub Pages-beschikbaarheid hangt af van je abonnement en organisatie-instellingen.
5. Maak de repository aan.

### 2. Supabase-project maken
1. Ga naar https://supabase.com en maak een account/project.
2. Bewaar het databasewachtwoord veilig.
3. Open **SQL Editor** in Supabase.
4. Open `supabase/schema.sql` uit deze repository, kopieer de volledige inhoud en voer die uit in SQL Editor.
5. Ga naar **Project Settings → API** (de naam van dit menu kan wijzigen).
6. Kopieer de project URL en de publieke anon/publishable key. **NOOIT** de `service_role` key kopiëren naar de website.

### 3. Configuratie maken
1. Download de repository op je Windows-computer (Code → Download ZIP) en pak die uit.
2. Kopieer `config.js.example` en noem de kopie `config.js`.
3. Open `config.js` in Kladblok of VS Code.
4. Vul `SUPABASE_URL` en `SUPABASE_ANON_KEY` in.
5. `index.html` laadt `config.js` al vóór `app.js`. Sla op. De publieke key is bedoeld voor de browser; de database moet door RLS beschermd zijn.

### 4. Lokaal testen
1. Installeer Visual Studio Code: https://code.visualstudio.com/
2. Open de map `TeacherHub`.
3. Installeer de extensie **Live Server**.
4. Rechtsklik `index.html` → **Open with Live Server**.
5. Maak een account met een test-e-mailadres. Controleer of e-mailbevestiging nodig is in Supabase Auth.
6. Voer eerst tests uit met fictieve gegevens.

### 5. GitHub Pages inschakelen
1. Upload alle bestanden naar de root van de repository, inclusief `index.html`, `styles.css`, `app.js`, `config.js` en de map `supabase`.
2. Open repository **Settings → Pages**.
3. Bij Build and deployment kies je **Deploy from a branch**.
4. Selecteer branch `main` en folder `/ (root)`, klik **Save**.
5. Wacht tot GitHub Pages een site-URL toont.
6. Voeg die URL bij Supabase **Authentication → URL Configuration** toe als Site URL en als toegestane redirect URL. Gebruik de exacte URL die GitHub toont.
7. Test aanmelden, uitloggen en databaseacties op de gepubliceerde site.

### 6. Eerste leerkrachtaccount instellen
Nieuwe accounts worden expres leerlingaccounts. Nadat je het e-mailadres hebt geverifieerd en hebt ingelogd:
1. Open Supabase → SQL Editor.
2. Voer alleen voor het geverifieerde account van de bevoegde leerkracht uit:
   `update public.profiles set role='teacher' where email='jouw-schoolmail@example.be';`
3. Ververs TeacherHub.
4. Doe dit nooit voor iemand zonder toestemming. Geef leerlingen geen teacher-rol.

### 7. Gratis mogelijkheden en mogelijke kosten
- GitHub Pages: statische hosting; voorwaarden en zichtbaarheid hangen af van repo-/organisatie-instellingen.
- Supabase Free: geschikt om een prototype te testen, maar heeft gebruikslimieten en kan projecten pauzeren of beperkingen opleggen volgens de actuele voorwaarden.
- AI: lokaal les-sjabloon is gratis. Echte AI via API is meestal gebruiksafhankelijk en kan kosten hebben.
- Monitoring: niet inbegrepen; geschikte producten kunnen betaald zijn en vereisen beheer op de leerlingtoestellen.

## Veiligheidscheck vóór gebruik met echte leerlingen
- Laat een schoolbeheerder en privacyverantwoordelijke de setup goedkeuren.
- Controleer alle RLS-policies met aparte testaccounts voor leerkracht en leerling.
- Stel accountbevestiging en wachtwoordbeleid in.
- Verwerk zo weinig mogelijk persoonsgegevens.
- Stel een bewaartermijn en verwijderprocedure vast.
- Zet nooit service-role keys, wachtwoorden, tokens of leerlinggegevens in GitHub.
- Controleer de actuele AVG/GDPR- en schoolregels voor jouw situatie.
